urlgeeneral=$("#url_raiz_proyecto").val();

window.addEventListener("load", function (event) {

    //listadocategorias();
    $(".loader").fadeOut("slow"); 

  
  });


  $("#switch1").on("change",function(){

        /*if ($(this).is(':checked')) {
            console.log($(this).val() + ' is now checked');
            $("#solomiembro").hide();

        } else {
            console.log($(this).val() + ' is now unchecked');
            $("#solomiembro").show();
        }*/

        alert("hola");


   });
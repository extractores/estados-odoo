<?php

namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Productos;
use App\Stock;
use App\fabricante;
use App\pedido_cab;
use App\pedido_det;
use App\Vendedores;
use App\jefeventas;
use App\supervisor;
use App\Compras;
use App\Detalle_compras;
use DB;
use App\Clientes;
use App\Promo_cabecera;
use Carbon\Carbon;
class Carga extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'carga:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'SICRONIZACIÓN CUBO';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        //draft, confirmes, planned, shipping, delivered, cancelled,


        $curl = curl_init();

        $datos=$this->token();
        $token=json_decode($datos,true);

        session(['key' =>$token]);


        //return response()->json($v["result"]["data"]["token"]);

        //print_r($v);exit();
        //10---

        $fechauno='2022/08/06';
        $fechados='2022/08/06';



       curl_setopt_array($curl, array(
       CURLOPT_URL => 'https://economysa.grupoquanam.com/api/customer/history?dateRange='.$fechauno.'-'.$fechados,
       CURLOPT_RETURNTRANSFER => true,
       CURLOPT_ENCODING => '',
       CURLOPT_MAXREDIRS => 10,
       CURLOPT_TIMEOUT => 0,
       CURLOPT_FOLLOWLOCATION => true,
       CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
       CURLOPT_CUSTOMREQUEST => 'GET',
       CURLOPT_HTTPHEADER => array(
           'Authorization: Bearer '.$token["result"]["data"]["token"],
           'Cookie: session_id=7b5f30fe09286bef1815f1a4aa16def6d0a6d38f'
       ),
       ));

       $response = curl_exec($curl);

       curl_close($curl);
       $pedidos=json_decode($response,true);

       
     
       for ($i=0; $i <count($pedidos["data"]) ; $i++) {

        $pedido=pedido_cab::where('id_odoo','=',$pedidos["data"][$i]["id"])->first();

        if( $pedido==null){
            $pedido=new pedido_cab;
        }


        $pedido->id_odoo=$pedidos["data"][$i]["id"];
        $pedido->nro_order=$pedidos["data"][$i]["nro_order"];
        $pedido->date_order=$pedidos["data"][$i]["date_order"];
        $pedido->date_emision=$pedidos["data"][$i]["date_emision"];
        $pedido->company_id=$pedidos["data"][$i]["company_id"];
        $pedido->ruta_master=$pedidos["data"][$i]["ruta_master"];
        $pedido->ruta_dia=$pedidos["data"][$i]["ruta_dia"];
        $pedido->date_delivery=$pedidos["data"][$i]["date_delivery"];

        if(!empty($pedidos["data"][$i]["status"])){


            $valor=count($pedidos["data"][$i]["status"]);
 
            if($valor==1){
 
               $pedido->state =$pedidos["data"][$i]["status"][0]["status_economysa"];
            }else{
 
                $dato=$valor -1;
                $pedido->state=$pedidos["data"][$i]["status"][$dato]["status_economysa"];
 
            }
 
 
 
         }


         $pedido->tipo_documento=$pedidos["data"][$i]["tipo_documento"];
         $pedido->numero_comprobante=$pedidos["data"][$i]["numero_comprobante"];
         $pedido->fecha_liquidacion=$pedidos["data"][$i]["fecha_liquidacion"];
         $pedido->total_amt=$pedidos["data"][$i]["total_amt"];
         $pedido->fecha_cobranza=$pedidos["data"][$i]["fecha_cobranza"];
         $pedido->total_amt_inv=$pedidos["data"][$i]["total_amt_inv"];
         $pedido->total_discount=$pedidos["data"][$i]["total_discount"];
         $pedido->id_almacen=$pedidos["data"][$i]["id_almacen"];
 
         if(!empty($pedidos["data"][$i]["reason_reject"])){
 
             $pedido->id_mot_r=$pedidos["data"][$i]["reason_reject"]["id"];
             $pedido->reason_reject=$pedidos["data"][$i]["reason_reject"]["name"];
 
 
         }



         $pedido->forma_pago=$pedidos["data"][$i]["forma_pago"];

         $pedido->codigo_dir=$pedidos["data"][$i]["direccion_entrega"]["id"];
 
         $pedido->dir_entrega=$pedidos["data"][$i]["direccion_entrega"]["name"];
 
         if(!empty($pedidos["data"][$i]["price_list"])){
 
             $pedido->id_list_price=$pedidos["data"][$i]["price_list"]["id"];
             $pedido->price_list=$pedidos["data"][$i]["price_list"]["name"];
 
 
         }
 
 
         $pedido->idcliente_odoo=$pedidos["data"][$i]["partner_id"]["id"];
 
        


         $direciox=$this->dir_cliente($pedidos["data"][$i]["partner_id"]["id"],$pedidos["data"][$i]["direccion_entrega"]["id"]);
         //$pedido->modulo=$direciox[0]["zone_id"]["name"];
        
         if(!empty($direciox[0]["canal_ids"])){

            $pedido->id_canal=$direciox[0]["canal_ids"][0]["id"];
            $pedido->canal=$direciox[0]["canal_ids"][0]["name"];
 
         }
 
 
         if(!empty($direciox[0]["longitude"])){
 
            $pedido->logx=$direciox[0]["longitude"];
         }
 
         if(!empty($direciox[0]["latitude"])){
 
            $pedido->laty=$direciox[0]["latitude"];
         }
 
         if(!empty($direciox[0]["Schedule"])){
 
             $pedido->schedule=$direciox[0]["Schedule"];
 
          }
 
          if(!empty($direciox[0]["zone_id"])){
 
             $pedido->modulo=$direciox[0]["zone_id"]["name"];
          }

          if(!empty($direciox[0]["officeId"])){

            $pedido->officeId=$direciox[0]["officeId"]["id"];
            $pedido->officeId_name=$direciox[0]["officeId"]["name"];

         }

          

          
        $pedido->idclie=$pedidos["data"][$i]["partner_id"]["code"];
        $pedido->razon_social=$pedidos["data"][$i]["partner_id"]["name"];

        if(!empty($pedidos["data"][$i]["partner_id"]["l10n_pe_district"])){



           $pedido->cod_distrito=$pedidos["data"][$i]["partner_id"]["l10n_pe_district"]["id"];


           $pedido->distrito=$pedidos["data"][$i]["partner_id"]["l10n_pe_district"]["name"];
           $pedido->ubigeo=$pedidos["data"][$i]["partner_id"]["l10n_pe_district"]["ubigeo"];

        }

        if(!empty($pedidos["data"][$i]["seller_id"])){

           $pedido->seller_id=$pedidos["data"][$i]["seller_id"]["id"];
           $pedido->seller_name=$pedidos["data"][$i]["seller_id"]["name"];

        }

      if(!empty($pedidos["data"][$i]["user_delivery"])){

       $pedido->driver_id=$pedidos["data"][$i]["user_delivery"]["id"];
       $pedido->driver=$pedidos["data"][$i]["user_delivery"]["name"];

      }

      if(!empty($pedidos["data"][$i]["partner_id"]["giro_id"])){

        $pedido->giro_id=$pedidos["data"][$i]["partner_id"]["giro_id"]["id"];
        $pedido->giro=$pedidos["data"][$i]["partner_id"]["giro_id"]["name"];
 
 
       }
 
         $infx=Carbon::parse($pedidos["data"][$i]["date_order"]);
         $pedido->periodo=$infx->format('Ym');
         $diax=Carbon::parse($pedidos["data"][$i]["date_order"]);
         $pedido->dis_visita=$infx->format('d');
         $pedido->idmone=1;
         $pedido->tipocambio=1;
         $this->clientes($pedidos["data"][$i]["partner_id"]["id"]);
 
 
          $pedido->save();

          for ($j=0; $j <count($pedidos["data"][$i]["lines"]) ; $j++) {

            $detalle=pedido_det::where('id_linea_odo','=',$pedidos["data"][$i]["lines"][$j]["id"])->first();

            if($detalle==null){

                $detalle=new pedido_det;
            }

           $detalle->id_linea_odo=$pedidos["data"][$i]["lines"][$j]["id"];
           $detalle->id_ordder=$pedidos["data"][$i]["id"];
           $detalle->product_id=$pedidos["data"][$i]["lines"][$j]["product_id"]["id"];
           $detalle->product_name=$pedidos["data"][$i]["lines"][$j]["product_id"]["name"];
           $detalle->tipo_producto=$pedidos["data"][$i]["lines"][$j]["product_id"]["tipo_producto"];
           $detalle->unidad_medida=$pedidos["data"][$i]["lines"][$j]["product_id"]["unidad_medida"];

           if(!empty($pedidos["data"][$i]["lines"][$j]["product_id"]["precio_compra"])){

               $detalle->precio_compra=$pedidos["data"][$i]["lines"][$j]["product_id"]["precio_compra"];
           }



           if(!empty($pedidos["data"][$i]["lines"][$j]["product_id"]["codigo_fabricante"])){

            $detalle->codigo_fabricante=$pedidos["data"][$i]["lines"][$j]["product_id"]["codigo_fabricante"];

           }else{
            $detalle->codigo_fabricante=0;

           }

           $detalle->discount_product=$pedidos["data"][$i]["lines"][$j]["product_id"]["discount_product"];
           $detalle->unidades_complementarias_faltantes_master=$pedidos["data"][$i]["lines"][$j]["product_id"]["unidades_complementarias_faltantes_master"];
           $detalle->price_unit=$pedidos["data"][$i]["lines"][$j]["price_unit"];
           $detalle->precio_sin_igv=$pedidos["data"][$i]["lines"][$j]["precio_sin_igv"];
           $detalle->product_uom_qty=$pedidos["data"][$i]["lines"][$j]["product_uom_qty"];

           if(!empty($pedidos["data"][$i]["lines"][$j]["tax_id"])){

               $detalle->tax_id=$pedidos["data"][$i]["lines"][$j]["tax_id"][0]["id"];

           }

           $detalle->impuesto=18;//(double)$pedidos["data"][$i]["lines"][$j][0]["tax_id"]["name"];
           $detalle->monto_impuesto=$pedidos["data"][$i]["lines"][$j]["monto_impuesto"];
           $detalle->is_reward_line=$pedidos["data"][$i]["lines"][$j]["is_reward_line"];
           //$detalle->tax_id=$pedidos["data"][$i]["lines"][$j]["tax_id"]["id"];
           if(!empty($pedidos["data"][$i]["lines"][$j]["cod_promocion"])){

               $detalle->cod_promocion=$pedidos["data"][$i]["lines"][$j]["cod_promocion"]["id"];
               $detalle->nombre_promo=$pedidos["data"][$i]["lines"][$j]["cod_promocion"]["name"];

           }

           $detalle->save();

           //return response()->json($detalle);

           //print_r('');exit();

           //print_r($detalle);exit();


        }

    }

          



        //$this->productos();
       //$this->stock();
       //$this->compras();
        //$this->vendedor();
        //$this->jefes();
        //$this->supervisor();
       // $this->proveedores();





        return 'EJECUTADO CORRECTAMENTE';
    }

    //FUNCION PARA CARGAR EL VENDEDOR
    public function vendedor(){

        $vendedores=DB::connection('pgsql2')->table('crm_team_sale_canal as ca')
        ->join('crm_team as crt','crt.id','=','ca.team_id')
        ->join('crm_team_salesman as v','ca.id','=','v.canal_id')
        ->join('res_users as ur','v.user_id','=','ur.id')
        ->join('res_partner as cli','cli.id','=','ur.partner_id')
        //->join('res_users as rs ','','')
        ->select('v.user_id','ca.supervisor_id','ca.name as supervisor','cli.name as vendedor','ca.id as id_canal','ca.name as canal',
                 'crt.id as id_equipo','crt.name as fuerza')
        ->where('cli.type','=','contact')
        ->get();

        for ($i=0; $i <count($vendedores) ; $i++) {

            $vendedor=Vendedores::where('cod_vendedor','=',$vendedores[$i]->user_id)->first();

            if($vendedor==null){
                $vendedor=new Vendedores;
            }

            $vendedor->cod_vendedor=$vendedores[$i]->user_id;
            $vendedor->cod_supervisor=$vendedores[$i]->supervisor_id;
            $vendedor->supervisor=$this->supervisory($vendedores[$i]->supervisor_id);
            $vendedor->vendedor=$vendedores[$i]->vendedor;
            $vendedor->id_equipo=$vendedores[$i]->id_equipo;
            $vendedor->equipo=$vendedores[$i]->fuerza;
            $vendedor->id_canal=$vendedores[$i]->id_canal;
            $vendedor->canal=$vendedores[$i]->canal;
            $vendedor->save();

            //return response()->json($vendedor);
            //print_r('');exit();

        }




    }
    //funcion supervisory
    public function supervisory($codigo){


        $jefes=DB::connection('pgsql2')->table('crm_team_sale_canal as cr')
        ->join('res_users as rs','cr.supervisor_id','=','rs.id')
        ->join('res_partner as res','res.id','=','rs.partner_id')
        ->select('cr.supervisor_id','res.name')
        ->where('cr.supervisor_id','=',$codigo)
        ->get();

        return $jefes[0]->name;

    }


    //FUNCION PARA SICRONIZAR LOS DATOS DE SUPERVISOR
    public function jefes(){

        $jefes=DB::connection('pgsql2')->table('crm_team as crt')
        ->join('res_users as ur','crt.user_id','=','ur.id')
        ->join('res_partner as cli','cli.id','=','ur.partner_id')
        ->select('crt.id','cli.name as jefedes','crt.name as equipo')
        ->get();

        for ($i=0; $i <count($jefes) ; $i++) {

            $jefe=jefeventas::where('cod_jefeventas','=',$jefes[$i]->id)->first();

            if($jefe==null){

                $jefe=new jefeventas;
            }

            $jefe->cod_jefeventas=$jefes[$i]->id;
            $jefe->nombre=$jefes[$i]->jefedes;
            $jefe->equipo=$jefes[$i]->equipo;
            $jefe->save();

      }




    }
    //FUNCION PARA CARGAR LOS SUPERVISORS
    public function supervisor(){
        $supervisores=DB::connection('pgsql2')->table('crm_team_sale_canal as ca')
        ->join('crm_team as crt','crt.id','=','ca.team_id')
        ->join('res_users as ur','ur.id','=','ca.supervisor_id')
        ->join('res_partner as cli','cli.id','=','ur.partner_id')
        ->select('ca.supervisor_id','cli.name as supervisor','ca.id as id_canal','ca.name as canal',
                 'crt.id as id_equipo','crt.name as equipo')
        ->get();

        foreach($supervisores as $s){

            $r=supervisor::where('cod_canal','=',$s->id_canal)->first();

            if($r==null){

              $r=new supervisor;

            }

            $r->cod_supervisor=$s->supervisor_id;
            $r->supervisor=$s->supervisor;
            $r->cod_canal=$s->id_canal;
            $r->canal=$s->canal;
            $r->cod_equipo=$s->id_equipo;
            $r->equipo=$s->equipo;
            $r->save();

       }



    }
    //FUNCION PARA PODER REALIZAR LA SICRONIZACIÓN DE PROVEEDORES
    public function proveedores(){


        $curl = curl_init();

        $datos=$this->token();
        $token=session('key');

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://economysa.grupoquanam.com/api/customer?company_id=1&active=1&is_manufacter=True',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer '.$token["result"]["data"]["token"],
            'Cookie: session_id=a946b4c343cf52f88b1fd0ffff68956c2f1f8b24'
          ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $ind_desp=json_decode($response,true);
        $codigo_proveedor=0;
        //print_r($ind_desp["data"][0]["l10n_latam_identification_type_id"]["id"]);exit();


        for($i=0;$i<count($ind_desp["data"]);$i++){

            $fabricante=fabricante::where('cod_odoo','=',$ind_desp["data"][$i]["partner_id"])->first();

            if($fabricante==null){

                $fabricante=new fabricante;

            }


            $fabricante->cod_odoo=$ind_desp["data"][$i]["partner_id"];
            $fabricante->cod_eco=$ind_desp["data"][$i]["code"];
            $fabricante->tipo_documento=$ind_desp["data"][$i]["l10n_latam_identification_type_id"]["name"];
            $fabricante->documento=$ind_desp["data"][$i]["vat"];
            $fabricante->proveedor=$ind_desp["data"][$i]["full_name"];
            $fabricante->cod_compania=$ind_desp["data"][$i]["company_id"]["id"];
            $fabricante->compania=$ind_desp["data"][$i]["company_id"]["name"];
            $fabricante->save();

        }




    }

    //FUNCION MOTIVO DE RECHAZO ID
    public function motivo($motivos){

        $curl = curl_init();

        $token=session('key');

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://economysa.grupoquanam.com/api/reason/reject',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer '.$token["result"]["data"]["token"],
            'Cookie: session_id=c85494d02770c8288198cd7f075bbae385eac610'
          ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $motivo=json_decode($response,true);
        $idmotivo=0;

        for ($i=0; $i <count($motivo["data"]) ; $i++) {

               if($motivo["data"][$i]["name"]==$motivos){

                $idmotivo=$motivo["data"][$i]["reason_id"];

               }


        }



        return $idmotivo;





    }
    //FUNCION TARIFA
    public function tarifas($tarifa){

        $curl = curl_init();

        $token=session('key');

            curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://economysa.grupoquanam.com/api/pricelist',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$token["result"]["data"]["token"],
                'Cookie: session_id=c85494d02770c8288198cd7f075bbae385eac610'
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            $motivo=json_decode($response,true);
            $idlista=0;

            for ($i=0; $i <count($motivo["data"]) ; $i++) {

                   if($motivo["data"][$i]["name"]==$tarifa){

                    $idlista=$motivo["data"][$i]["id"];

                   }


            }



            return $idlista;


    }
    public function clientes($cod_cliente){


        $curl = curl_init();

        //$datos=$this->token();
        //$token=json_decode($datos,true);
        $token=session('key');


                        curl_setopt_array($curl, array(
                            CURLOPT_URL => 'https://economysa.grupoquanam.com/api/customer?company_id=1&partner_id='.$cod_cliente.'&active=1',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => '',
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 0,
                            CURLOPT_FOLLOWLOCATION => true,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => 'GET',
                            CURLOPT_HTTPHEADER => array(
                                'Authorization: Bearer '.$token["result"]["data"]["token"],
                                'Cookie: session_id=c85494d02770c8288198cd7f075bbae385eac610'
                            ),
                            ));


                $response = curl_exec($curl);

                curl_close($curl);
                $clientes=json_decode($response,true);

                for ($i=0; $i < count($clientes["data"]); $i++) {

                $cliente=Clientes::where('idoo','=',$clientes["data"][$i]["partner_id"])->first();

                if($cliente==null){
                    $cliente=new Clientes;
                    }

                $cliente->idoo=$clientes["data"][$i]["partner_id"];
                $cliente->emp_id=$clientes["data"][$i]["company_id"]["id"];
                $cliente->cli_idclie=$clientes["data"][$i]["code"];
                if($clientes["data"][$i]["l10n_latam_identification_type_id"]["id"]==5){

                    $cliente->tipo_doc=$clientes["data"][$i]["l10n_latam_identification_type_id"]["name"];
                    $cliente->cli_nrodoc=$clientes["data"][$i]["vat"];

                }else{

                    $cliente->tipo_doc=$clientes["data"][$i]["l10n_latam_identification_type_id"]["name"];
                    $cliente->cli_ruc=$clientes["data"][$i]["vat"];


                }

                $cliente->cli_razsoc=$clientes["data"][$i]["full_name"];
                $cliente->cli_domifis=$clientes["data"][$i]["street"];
                $cliente->idcategoabc=$clientes["data"][$i]["tier"];
                $cliente->pais=$clientes["data"][$i]["country_id"]["name"];
                $cliente->departamento=$clientes["data"][$i]["state_id"]["name"];
                $cliente->provincia=$clientes["data"][$i]["city_id"]["name"];
                $cliente->distrito=$clientes["data"][$i]["l10n_pe_district"]["name"];
                $cliente->pricelist_id=$clientes["data"][$i]["pricelist_id"]["id"];
                $cliente->pricelist=$clientes["data"][$i]["pricelist_id"]["name"];
                $cliente->estado_cliente=$clientes["data"][$i]["status_cliente"];
                $cliente->estado_cliente=$clientes["data"][$i]["status_cliente"];
                $cliente->es_fabricante=$clientes["data"][$i]["fabricante"];
                $cliente->es_conducto=$clientes["data"][$i]["conductor"];
                $cliente->validado_sunat=$clientes["data"][$i]["is_validate"];
                if(!empty($clientes["data"][$i]["deliveryAddresses"][0]["line_business_id"]["id"])){

                    $cliente->id_giro=$clientes["data"][$i]["deliveryAddresses"][0]["line_business_id"]["id"];
                }
                if(!empty($clientes["data"][$i]["deliveryAddresses"][0]["l10n_pe_district"]["ubigeo"])){

                    $cliente->ubigeo=$clientes["data"][$i]["deliveryAddresses"][0]["l10n_pe_district"]["ubigeo"];

                }

                
                $cliente->save();







                }

                return 'OK';


}

public function dir_cliente($cod_cliente,$cod_dir){

        $curl = curl_init();

        //$datos=$this->token();
        //$token=json_decode($datos,true);
        $token=session('key');


        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://economysa.grupoquanam.com/api/customer?company_id=1&partner_id='.$cod_cliente.'&active=1',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$token["result"]["data"]["token"],
                'Cookie: session_id=c85494d02770c8288198cd7f075bbae385eac610'
            ),
            ));


            $response = curl_exec($curl);

            curl_close($curl);
            $clientes=json_decode($response,true);
            $info=0;

            for ($i=0; $i < count($clientes["data"]); $i++) {

                 for ($j=0; $j <count($clientes["data"][$i]["deliveryAddresses"]) ; $j++) {

                     if($clientes["data"][$i]["deliveryAddresses"][$j]["id"]==$cod_dir){

                         $info=$clientes["data"][$i]["deliveryAddresses"];
                     }


                 }

            }

            return $info;





     }

     public function compras(){

        $curl = curl_init();

        $token=session('key');

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://economysa.grupoquanam.com/api/purchase?company_id=1&dataRange=2022/07/01-2022/07/30',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer '.$token["result"]["data"]["token"],
            'Cookie: session_id=7b5f30fe09286bef1815f1a4aa16def6d0a6d38f'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $compras=json_decode($response,true);

        for ($i=0; $i <count($compras["data"]) ; $i++) {

            $compra=Compras::where('id_odoo','=',$compras["data"][$i]["id"])->first();

            if($compra==null){
                $compra=new Compras;
            }
            $compra->id_odoo=$compras["data"][$i]["id"];
            $compra->company_id=$compras["data"][$i]["company_id"];
            $compra->nro_order=$compras["data"][$i]["nro_order"];
            $compra->estado_orden=$compras["data"][$i]["state"];
            $compra->date_approve=$compras["data"][$i]["date_approve"];
            $compra->date_planned=$compras["data"][$i]["date_planned"];
            $compra->date_planned=$compras["data"][$i]["date_planned"];
            //$compra->numero_documento_proveedor=$compras["data"][$i]["nro_doc_partner"];
            $compra->numero_documento_proveedor=$compras["data"][$i]["nro_doc_partner"];
            $compra->amount_tax=$compras["data"][$i]["amount_tax"];
            $compra->amount_total=$compras["data"][$i]["amount_total"];
            if(!empty($compras["data"][$i]["warehouse"])){

                $compra->warehouse_id=$compras["data"][$i]["warehouse"]["warehouse_id"];
                $compra->warehouse_name=$compras["data"][$i]["warehouse"]["warehouse_name"];

            }

            $compra->save();



           for ($j=0; $j <count($compras["data"][$i]["lines"]) ; $j++) {

               $detalle=new Detalle_compras;
               $detalle->id_compra=$compras["data"][$i]["id"];
               $detalle->product_id=$compras["data"][$i]["lines"][$j]["product_id"]["id"];
               $detalle->producto=$compras["data"][$i]["lines"][$j]["product_id"]["name"];

               if(!empty($compras["data"][$i]["lines"][$j]["product_id"]["uom_id"])){
                $detalle->unidad_venta=$compras["data"][$i]["lines"][$j]["product_id"]["uom_id"]["name"];
               }
               if(!empty($compras["data"][$i]["lines"][$j]["product_id"]["uom_po_id"])){

                $detalle->unidad_medida_master=$compras["data"][$i]["lines"][$j]["product_id"]["uom_po_id"]["name"];

               }
               $detalle->precio_compra=$compras["data"][$i]["lines"][$j]["product_id"]["precio_compra"];

               if(!empty($compras["data"][$i]["lines"][$j]["product_id"]["manufacter_id"])){

                $detalle->cod_proveedor=$compras["data"][$i]["lines"][$j]["product_id"]["manufacter_id"]["id"];
                $detalle->proveedor=$compras["data"][$i]["lines"][$j]["product_id"]["manufacter_id"]["name"];

               }

               $detalle->cantidad_rechazada=$compras["data"][$i]["lines"][$j]["product_id"]["cantidad_rechazada"];
               $detalle->unidad_medida_master=$compras["data"][$i]["lines"][$j]["product_id"]["unidad_medida_master"];
               $detalle->unidad_medida_rechazada=$compras["data"][$i]["lines"][$j]["product_id"]["unidad_medida_rechazada"];
               $detalle->conver_master_unidad=$compras["data"][$i]["lines"][$j]["product_id"]["conver_master_unidad"];
               $detalle->cantidad_master=$compras["data"][$i]["lines"][$j]["product_id"]["cantidad_master"];
               $detalle->cantidad_unidades=$compras["data"][$i]["lines"][$j]["product_id"]["cantidad_unidades"];
               $detalle->costo_master=$compras["data"][$i]["lines"][$j]["product_id"]["costo_master"];
               $detalle->price_unit=$compras["data"][$i]["lines"][$j]["price_unit"];
               $detalle->precio_sin_igv=$compras["data"][$i]["lines"][$j]["precio_sin_igv"];
               $detalle->product_qty=$compras["data"][$i]["lines"][$j]["product_qty"];


               if(!empty($compras["data"][$i]["lines"][$j]["tax_id"])){

                $detalle->tax_id=$compras["data"][$i]["lines"][$j]["tax_id"][0]["id"];
                $detalle->impuesto=$compras["data"][$i]["lines"][$j]["tax_id"][0]["name"];

               }

               $detalle->save();

               //return response()->json($detalle);

               //print_r('');exit();

              //










           }



        }





    }

    public function productos(){


        $curl = curl_init();
        $token=session('key');
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://economysa.grupoquanam.com/api/product?active=True',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
              'Authorization: Bearer '.$token["result"]["data"]["token"],
              'Cookie: session_id=a946b4c343cf52f88b1fd0ffff68956c2f1f8b24'
            ),
          ));

          $response = curl_exec($curl);


          curl_close($curl);
          $productos=json_decode($response,true);

          for ($i=0; $i < count($productos["data"]); $i++) {

            $stock=Productos::where('cod_odoo','=',$productos["data"][$i]["product_id"])->first();

            if($stock==null){

                $stock=new Productos;
            }



             $stock->tipoproducto=$productos["data"][$i]["type"];
             //$stock->emp_id='';
            if(!empty($productos["data"][$i]["manufacter_id"])){

                $stock->prov_id=$productos["data"][$i]["manufacter_id"]["id"];
                $stock->proveedor=$productos["data"][$i]["manufacter_id"]["name"];


            }


             $stock->codart=$productos["data"][$i]["default_code"];
             $stock->producto=$productos["data"][$i]["name"];
             $stock->nombrecorto=$productos["data"][$i]["shortName"];
             $stock->idcategoria=$productos["data"][$i]["categ_id"]["id"];
             $stock->categoria=$productos["data"][$i]["categ_id"]["name"];
             $stock->idlinea=$productos["data"][$i]["brand_line_id"]["id"];
             $stock->linea=$productos["data"][$i]["brand_line_id"]["name"];
             //$stock->idsublinea='';
             //$stock->sublinea='';
             $stock->idmarca=$productos["data"][$i]["brand_id"]["id"];
             $stock->marca=$productos["data"][$i]["brand_id"]["name"];
             //$stock->idsubmarca='';
             //$stock->submarca='';
             //$stock->codori='';
             $stock->empaquecompra=$productos["data"][$i]["uom_po_id"]["name"];
             //$stock->upreoriginal='';
             $stock->empaquevta=$productos["data"][$i]["purchase_ackaging"]["name"];
             $stock->undpresenta=$productos["data"][$i]["uom_id"]["name"];
             $stock->estado_articulo=$productos["data"][$i]["status_product"];
             $stock->estado_compra=$productos["data"][$i]["status_product"];
             $stock->estado_venta=$productos["data"][$i]["status_product"];
             $stock->peso=$productos["data"][$i]["weight_product"];
             //$stock->art_unimed='';
             $stock->volumen=$productos["data"][$i]["volume_product"];
             $stock->preciovta=$productos["data"][$i]["list_price"];

             if(!empty($productos["data"][$i]["seller"])){

                $stock->preciocompra=$productos["data"][$i]["seller"][0]["price"];


             }

             if(!empty($productos["data"][$i]["taxes_id"])){

              $stock->tipoigv=$productos["data"][$i]["taxes_id"][0]["name"];
              $stock->igv=$productos["data"][$i]["taxes_id"][0]["amount"];

             }

             $stock->unidad_sunat=$productos["data"][$i]["unidad_sunat"];
             $stock->codigo_compra_proveedor=$productos["data"][$i]["codigo_compra_proveedor"];
             $stock->codigo_barras=$productos["data"][$i]["barcode"];
             $stock->create_date=$productos["data"][$i]["create_date"];
             $stock->write_date=$productos["data"][$i]["write_date"];
             $stock->write_uid=$productos["data"][$i]["write_uid"];
             $stock->cod_odoo=$productos["data"][$i]["product_id"];
             $stock->conver_master_unidad=$productos["data"][$i]["conver_master_unidad"];
             $stock->save();
             //return response()->json($stock);
             //print_r('bien');exit();


          }



    }



    public function stock(){



        $curl = curl_init();
        $token=session('key');


        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://economysa.grupoquanam.com/api/product?active=True',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer '.$token["result"]["data"]["token"],
            'Cookie: session_id=a946b4c343cf52f88b1fd0ffff68956c2f1f8b24'
          ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        //echo($response);
          $productos=json_decode($response,true);
          $date = Carbon::now();


        for ($i=0; $i < count($productos["data"]); $i++) {


             for($j=0;$j<count($productos["data"][$i]["qty_available"]);$j++){

                //print_r($productos["data"][$i]["qty_available"][$j]);exit();
                $stock=Stock::where('almacen_id','=',$productos["data"][$i]["qty_available"][$j]["id"])
                ->where('cod_producto','=',$productos["data"][$i]["default_code"])
                ->first();


                if($stock==null){
                    $stock=new Stock;
                }
                //$stock=new Stock;
                $stock->cod_producto=$productos["data"][$i]["default_code"];
                $stock->almacen_id=$productos["data"][$i]["qty_available"][$j]["id"];
                $stock->stock_diponible=$productos["data"][$i]["qty_available"][$j]["stock_diponible"];
                $stock->stock_seguridad=$productos["data"][$i]["qty_available"][$j]["stock_seguridad"];
                $stock->cantidad_mano=$productos["data"][$i]["qty_available"][$j]["cantidad_mano"];
                $stock->total_soles=round($productos["data"][$i]["qty_available"][$j]["total_costo"],2);
                $stock->fecha=date('Y-m-d');
                $stock->periodo=date('Ym');
                $stock->hora=$date->toTimeString();
                $stock->masterStockAmount=$productos["data"][$i]["masterStockAmount"];
                $stock->save();




             }




        }

        //print_r('ok');exit();






    }



    public function token(){

        $curl = curl_init();

            curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://economysa.grupoquanam.com/api/login',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{
                "params":{
                    "company_id":1,
                    "login":"sistemas@economysa.pe",
                    "password":"Eco123."
                }
            }
            ',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NjAzMjIwNzUsInVzZXJfaWQiOjQyLCJ1c2VyX25hbWUiOiJURVJFU0EiLCJjb21wYW55X2lkIjoxLCJjb21wYW55X25hbWUiOiJFQ09OT01ZU0EgU0FDIiwidXNlcl90eiI6IkV1cm9wZS9NYWRyaWQiLCJjaGFubmVsX2lkIjoxMTYsImNoYW5uZWxfbmFtZSI6IkNBTkFMIERJR0lUQUwiLCJzYWxlX3RlYW1faWQiOjMsInNhbGVfdGVhbV9uYW1lIjoiRS1DT01NRVJDRSIsInJvdXRlX3BlcmlvZF9pZCI6MTExMiwicm91dGVfbWFzdGVyX2lkIjo0MzUsImFycmF5X21vZHVsb3MiOlsiMjA2MyIsIjMzMDQ5IiwiMzMwNjkiLCIzMzEwMCIsIjMzMTcxIiwiMzMyMTEiLCIzMzIyNCIsIjMzMjI1IiwiMzMyMzAiLCIzMzI3MiIsIjMzMzA4IiwiMzMzNTkiLCIzMzM3MSIsIjMzMzc0IiwiNDMwMDciLCI0MzA4MSIsIjQzMTQwIiwiNDMxNzUiLCI0MzIyOSIsIjIwODMiLCI5OTk5OSIsIjA2MTU0IiwiMDYxNTYiLCIwNjE2MSIsIjA2MTcxIiwiMDYxNzMiLCIwNjIwMiIsIjA2MjQxIiwiMTAwMjAiLCIxMDAyMiIsIjEwMDI3IiwiMTAwNjkiLCIxMDA5MCIsIjEwMTU1IiwiMTAxNjMiLCIxMDE3MiIsIjEwMTc0IiwiMTAxODAiLCIxMDE4MyIsIjEwMjAxIiwiMTAyMjUiLCIxMDIyNyIsIjEwMjMxIiwiMTAyMzIiLCIxMDIzOCIsIjEwMjc1IiwiMTAzNDQiLCIxMDQzMCIsIjEwNDMyIiwiMTA0NDMiLCIxMDUwNCIsIjEwNTEwIiwiMjA3MyIsIjMwMDE5IiwiMTUwMDkiLCIxNTAxMiIsIjE1MDMzIiwiMTUwNDIiLCIxNTA0OCIsIjE1MDc1IiwiMTUwOTQiLCIxNTEzMSIsIjIwNTMiLCIyMjA0NSIsIjMwMDI2IiwiMzQwMTAiLCI0MDAwMyIsIjQwMDE3IiwiNDAwODgiLCI0MDA5MCIsIjQwMTA4IiwiNDEwNDciLCI0MTA1OCIsIjQxMDY1Il0sInR5cGVfdXNlciI6IiJ9.EEnQZu6nZNrPlXMxfGflpiyPpew6oYw7KdKy8VKJ1Wk',
                'Content-Type: application/json',
                'Cookie: session_id=08661fe10a6f86229808fc5873da6454c8b530b2'
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
           
          return $response;



    }









}

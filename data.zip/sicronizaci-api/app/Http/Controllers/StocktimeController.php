<?php

namespace App\Http\Controllers;

use App\stocktime;
use Illuminate\Http\Request;

class StocktimeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\stocktime  $stocktime
     * @return \Illuminate\Http\Response
     */
    public function show(stocktime $stocktime)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\stocktime  $stocktime
     * @return \Illuminate\Http\Response
     */
    public function edit(stocktime $stocktime)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\stocktime  $stocktime
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, stocktime $stocktime)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\stocktime  $stocktime
     * @return \Illuminate\Http\Response
     */
    public function destroy(stocktime $stocktime)
    {
        //
    }
}

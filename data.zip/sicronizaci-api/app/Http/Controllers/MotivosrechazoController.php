<?php

namespace App\Http\Controllers;

use App\motivosrechazo;
use Illuminate\Http\Request;

class MotivosrechazoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\motivosrechazo  $motivosrechazo
     * @return \Illuminate\Http\Response
     */
    public function show(motivosrechazo $motivosrechazo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\motivosrechazo  $motivosrechazo
     * @return \Illuminate\Http\Response
     */
    public function edit(motivosrechazo $motivosrechazo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\motivosrechazo  $motivosrechazo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, motivosrechazo $motivosrechazo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\motivosrechazo  $motivosrechazo
     * @return \Illuminate\Http\Response
     */
    public function destroy(motivosrechazo $motivosrechazo)
    {
        //
    }
}
